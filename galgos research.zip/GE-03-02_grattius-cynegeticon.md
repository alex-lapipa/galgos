---
document_id: "GE-03-02"
title: "Grattius's Cynegeticon: The Earliest Latin Dog-Breed Catalogue"
slug: "grattius-cynegeticon"
batch: "03"
document_type: "primary_source_analysis"
language: "en"
source_languages: ["la", "en"]
period_start: "63 BCE"
period_end: "14 CE"
geographies: ["Rome", "Gaul"]
entities: []
people: ["Grattius"]
dog_types: ["vertragus", "metagon", "Molossian", "Celtae"]
topics: ["dog breed catalogue", "Augustan poetry", "vertragus first mention"]
evidence_level: "confirmed"
source_quality: "tier_1"
created_at: "2026-08-30"
updated_at: "2026-08-30"
version: "1.0"
citation_count: 3
review_status: "draft"
---

# Grattius's Cynegeticon: The Earliest Latin Dog-Breed Catalogue

## Executive summary

Grattius (Grattius Faliscus), an Augustan-era Latin poet, wrote the *Cynegeticon*, which survives in 541 mutilated hexameters. It contains the earliest Latin breed catalogue organized by geographic origin, and gives what is very plausibly the earliest surviving reference to a fast, spotted dog cognate with the later "vertragus" — though under the spelling *Vertraha*.

## Historical context

Grattius flourished under Augustus (63 BCE–14 CE); the only ancient reference to him is Ovid, *Ex Ponto* IV.16.34. The poem survives in a single manuscript of c. 800 CE, mutilated toward the end. The standard edition is J. Wight Duff & Arnold M. Duff, *Minor Latin Poets* (Loeb, 1934); the full Latin text and Duff's translation are at LacusCurtius (penelope.uchicago.edu/Thayer/E/Roman/Texts/Grattius).

## Evidence

- **Breed catalogue by geographic origin (lines 150–170ff):** "Dogs belong to a thousand lands and they each have characteristics derived from their origin" (*mille canum patriae ductique ab origine mores / quisque suo*, lines 156–157). Asiatic breeds are listed before European; the **Celtae** ("Celtic dogs") are named between the Medi and Geloni (lines 155–157): "The Median dog... is a great fighter, and great glory exalts the far-distant Celtic dogs."
- **The Vertraha (lines 202–208):** for light hunting of antelope or hare, Grattius recommends Petronian dogs, "swift Sycambrians and the Vertraha coloured with yellow spots — swifter than thought or a winged bird it runs, pressing hard on the beasts it has found, though less likely to find them when they lie hidden." The Loeb notes that manuscripts of Martial give the variant spellings *vertragus/vertagus/vetragus* for the same word, and connect it to Arrian's Celtic etymology and the Italian *veltro* ("greyhound").
- **The metagon (lines 213ff):** a tracking dog "mentioned only by Grattius," associated with Sparta and Crete — a now-obscure type with no other surviving classical attestation.
- **Molossians (lines 179ff):** praised for serious combat: "you could not admire the renowned Molossians so much" for anything but fighting strength.
- **Iberian geographic (non-canine) references:** Grattius mentions the flax of Spanish **Saetabis** used for hunting nets, and the horses of the **Callaeci** (a people of Hispania Tarraconensis), which "can traverse the jagged Pyrenees" — though he would not trust a Spanish horse in the hunt (lines 514ff). These are geographic color, not canine evidence, but are worth noting as the poem's only Iberian material.

## Primary-source passages

> **Latin (lines 202–204, approximate):** *...et Vertraha, [color] croceis distincta notis... cogitatione velocior aut ave pinnis...*
> **English (Duff, Loeb, paraphrased):** "swift Sycambrians and the Vertraha coloured with yellow spots — swifter than thought or a winged bird it runs."

## Interpretation

Grattius gives us the earliest Latin trace of the word that becomes "vertragus," roughly a century before Martial's explicit naming and nearly two centuries before Arrian's full treatment. The spelling variance (*Vertraha* vs. *vertragus*) across manuscripts of Grattius, Martial, and later authors indicates a foreign (Celtic) loanword still settling into Latin orthography — consistent with the etymological analysis in `GE-02-02`. Grattius's catalogue-by-origin structure is also historically significant in its own right: it is the earliest surviving example of the "dogs classified by homeland and function" approach that recurs throughout this corpus's classical sources (and is explicitly flagged in `GE-01-05` as *not* equivalent to a modern closed-studbook "breed").

## Role of dogs in society

Grattius's poem is itself evidence of an aristocratic Roman literary culture interested in hunting-dog connoisseurship — cataloguing types by geography and specialized function (fighting, tracking, coursing) for an audience assumed to care about such distinctions.

## Connection to the Galgo Español

None established. Grattius's *Vertraha*/*vertragus* is explicitly a Celtic dog in this and later sources (see `GE-03-04`), not an Iberian one; any link to Iberia runs through the later etymological and Roman-Iberian material treated elsewhere in this batch, not through Grattius directly.

## Competing interpretations

Not significantly contested; the main scholarly uncertainty is textual (manuscript spelling variants of *vertragus*/*vertraha*), not interpretive.

## Evidential limitations

- The poem's manuscript state (mutilated, single surviving copy) means later portions and some readings are uncertain; line numbers here follow the standard Loeb edition.
- This file provides paraphrase rather than a full critical-edition Latin transcription; readers needing precise wording should consult the Loeb or LacusCurtius text directly.

## Claims table

| Claim ID | Claim | Status | Evidence | Source |
|---|---|---|---|---|
| GE03-02-C1 | Grattius gives the earliest Latin dog-breed catalogue organized by geographic origin | Confirmed | Direct textual content, lines 150–170ff | Grattius, *Cynegeticon* (Duff/Loeb) |
| GE03-02-C2 | The "Vertraha" in Grattius is the same word later spelled "vertragus" | Probable | Manuscript variant spellings noted by Loeb editors; consistent Celtic etymology | Loeb notes; cf. `GE-02-02` |
| GE03-02-C3 | Grattius locates the vertragus/vertraha in Iberia | Disproven or materially misleading | Grattius's Iberian references are to horses and flax, not dogs; the vertraha is grouped with Celtic-associated breeds | Grattius, *Cynegeticon* |

## Timeline events

- **63 BCE–14 CE:** Grattius's floruit under Augustus.
- **c. 800 CE:** Date of the single surviving manuscript of the *Cynegeticon*.
- **1934:** Standard modern Loeb edition (Duff & Duff, *Minor Latin Poets*).

## Related entities

- `GE-03-03_martial-epigram-vertragus.md` — the next, more explicit attestation of the word.
- `GE-03-04_arrian-cynegeticus.md` — the fullest classical treatment.
- `GE-02-02_vertragus-etymology-pre-roman-context.md` — linguistic background.

## Sources

1. Grattius, *Cynegeticon*, in Duff, J. W. & Duff, A. M. (eds./trans.) (1934). *Minor Latin Poets*, Loeb Classical Library.
2. LacusCurtius, "Grattius" (penelope.uchicago.edu/Thayer/E/Roman/Texts/Grattius).

## Suggested RAG questions

- What is the earliest Latin reference to the dog later known as the vertragus?
- How does Grattius organize his catalogue of dog breeds?
- Does Grattius connect any hunting dog to Iberia?
