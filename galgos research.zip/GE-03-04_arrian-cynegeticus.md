---
document_id: "GE-03-04"
title: "Arrian's Cynegeticus: The Vertragus, Celtic Coursing, and the Baetica Question"
slug: "arrian-cynegeticus"
batch: "03"
document_type: "primary_source_analysis"
language: "en"
source_languages: ["grc", "en"]
period_start: "~86 CE"
period_end: "~160 CE"
geographies: ["Nicomedia", "Gaul", "Baetica", "Cappadocia", "Athens"]
entities: ["Baetica"]
people: ["Arrian", "Ronald Syme", "A. B. Bosworth", "Philip A. Stadter"]
dog_types: ["vertragus", "Segusii"]
topics: ["coursing", "Celtic hunting custom", "Baetica proconsulship", "prosopography"]
evidence_level: "confirmed"
source_quality: "tier_1"
created_at: "2026-08-30"
updated_at: "2026-08-30"
version: "1.0"
citation_count: 10
review_status: "draft"
---

# Arrian's Cynegeticus: The Vertragus, Celtic Coursing, and the Baetica Question

## Executive summary

Lucius Flavius Arrianus of Nicomedia's *Cynegeticus* (Κυνηγετικός, c. 136–146 CE) is the single most important classical source on the vertragus — a Celtic sighthound coursed by sight rather than tracked by scent. Arrian describes its appearance, temperament, and Celtic hunting customs in detail, and names his own dog Hormé. **He locates all of this among the Celts/Gauls, never in Hispania.** Separately, modern prosopography does credibly place Arrian as Roman proconsul of Baetica (southern Spain) c. 123–126 CE — a real and well-supported biographical fact — but the popular claim that he "encountered the vertragus" or "hunted hares" specifically in Spain is an unverified embellishment not found in his own text.

## Historical context

Arrian (c. 86–after 160 CE), the "Second Xenophon," wrote his *Cynegeticus* explicitly as a supplement to Xenophon's earlier work of the same name (see `GE-03-01`), styling himself after his Athenian predecessor. The standard critical Greek text is A. G. Roos, *Flavii Arriani quae exstant omnia* II (Teubner, 1928/1968), 76–102, cited by chapter/section (e.g., *Cyn.* 3.6). English translations include William Dansey, *Arrian on Coursing* (1831); D. B. Hull, *Hounds and Hunting in Ancient Greece* (1964); and A. A. Phillips & M. M. Willcock, *Xenophon & Arrian: On Hunting* (1999).

## Evidence

**(a) The vertragus — appearance, temperament, use**
- **Etymology (*Cyn.* 3.6):** "the swift Celtic dogs are called *ouertragoi* (οὐέρτραγοι) in the Celtic tongue... from their swiftness." Arrian explicitly argues that Xenophon simply did not know these dogs, which is why Xenophon's *Cynegeticus* contains no sighthound coursing.
- **Appearance (*Cyn.* 4–6):** "Splendid animals, the best bred of them, with fine eyes, fine bodies all over, fine coats, and fine appearance" — long from head to tail, sturdily built, pointed muzzle, large soft ears, prominent bright eyes "that should astonish the man who sees them." Coat colour "makes no difference... not even if hounds are black or tan or white all over" (*Cyn.* 6.1) — again correcting Xenophon.
- **Care:** Arrian recommends hounds sleep with people, "as they become thereby affectionately attached — pleased with the contact of the human body."

**(b) Celtic hare-coursing and hunting on horseback**
Arrian distinguishes two kinds of Celtic (Gaulish) dog: rough, ugly scent hounds called **Segusii** (from a district of Gaul), comparable to Carian and Cretan dogs; and the swift **vertragi**. He describes **four Celtic modes of coursing**: (1) wealthy Gauls send hare-finders out at dawn, then course on horseback; (2) less wealthy amateurs beat the ground in a mounted line; (3) true enthusiasts on foot; (4) mixing scent-finders with sighthounds, the sighthounds serving "the use of Xenophon's nets." The point of the sport is explicitly **not the kill**: "one does not take hounds out in order to catch the beast, but for a race and competition, at least if one is a true sportsman." Arrian recounts personally dismounting to save the hare and even striking dogs that killed a good hare too readily. He records coursing cries: "Well done, Cirrha! Well done, Bonna! There's a good Hormé!"

**(c) His own dog Hormé**
Arrian names his own gray-eyed vertragus **Hormé** (Ὁρμή, "Impulse"), calling her "most swift and wise and divine" — using ἱερωτάτη, a superlative of ἱερός ("most sacred/divine"; Willcock renders it "out of this world"). Notably, this is the same name found on Xenophon's list of recommended dog names (*Cyn.* VII.5; see `GE-03-01`), a deliberate literary echo.

**(d) Does Arrian locate any of this in Hispania?**
**No.** Throughout the *Cynegeticus*, coursing and the vertragus are located among the **Celts/Gauls**, never in Spain. The association of the vertragus with Iberia found in modern popular sources is a **later conflation**, driven by (i) the *Canis Gallicus* → Spanish *galgo* etymology (see `GE-02-04`), and (ii) the separate, genuine fact of Arrian's Baetican governorship, addressed next.

**(e) The Baetica question — verified, not debunked**
This claim is **well-supported in modern scholarship**, contrary to any assumption it is likely false:
- The evidence is a **Greek verse inscription to Artemis discovered at Córdoba (Corduba) in 1968**, dedicated by "Arrianus, proconsul" (*Arrianos anthupatos*), offering the goddess verse "better than gold and silver" and preferable to "the spoils of the chase." First published by A. Tovar, "Un nuevo epigrama griego de Córdoba," in *Estudios sobre la obra de Américo Castro* (Madrid, 1971): 401–412, and republished as Tovar, "Un nuevo epigrama griego: ¿Arriano de Nicomedia, procónsul de Bética?", *Archivo Español de Arqueología* 48 (1975): 167–173.
- **Ronald Syme**, "The Career of Arrian," *HSCP* 86 (1982), writes: "At Corduba a proconsul of Baetica called Arrianus consecrates a Greek poem to Artemis, declaring his gift better than gold and silver, better than the products of hunting. None other than the author of the *Cynegetica*, the notion is highly attractive." He reconstructs sortition for the proconsulate c. 123–124 CE.
- **A. B. Bosworth**, "Arrian in Baetica," *GRBS* 17 (1976), examines the inscription and concludes the reconstruction "is both supported by the extant work of the historian Arrian and... only compatible with his authorship of the epigram" — the offer of verse instead of hunting spoils fits the philosopher-huntsman precisely.
- **Philip A. Stadter**, *Arrian of Nicomedia* (1980), and standard reference works accept the Baetican proconsulate (c. 123–126 CE) as part of Arrian's career: adlection to the Senate under Hadrian → legionary legate on the Danube → **proconsul of Baetica c. 123–126** → suffect consul 129/130 → **legatus Augusti of Cappadocia 131–137** (his major military command, repelling the Alani) → archon of Athens 145/6 → retirement.
- **Caveats:** (i) A minority view (M. Marcovich, *ZPE* 12, 1973) doubted the identification. (ii) A Spanish study, "Arriano de Nicomedia y la Bética, de nuevo," concludes from formal analysis of the inscription's support (a marble altar of Almadén de la Plata) that "the piece was made at the beginning of the 3rd c. CE, so that it is either a later copy of the original monument, or else the dedicant was not Arrian of Nicomedia." (iii) **Even granting the governorship, the inscription says nothing about hunting hares in Spain.** The popular claim that Arrian "first encountered the vertragus in Baetica" traces to the Dog Law Reporter blog ("Anthropomorphism in Antiquity," May 2011), which reports that "Richard Hawkins suggests he may have first encountered the vertragus" there — explicitly **speculation, not fact**, and the *Cynegeticus* itself frames the vertragus as Celtic/Gaulish throughout.

## Primary-source passages

> *Cyn.* 3.6 (paraphrased from the Greek, per Stadter/Bosworth): the swift Celtic dogs are called *ouertragoi* in the Celtic language, named not for any country but for their speed.

> Arrian on the purpose of coursing (paraphrased): the point of taking hounds out is not to catch the animal but to enjoy the contest and competition — a true sportsman lets the hare go free if it has run well.

## Interpretation

Two separate and independently well-evidenced facts should be held apart, and this file's central methodological contribution is keeping them apart where popular sources routinely merge them: (1) Arrian gives the fullest surviving classical account of a Celtic sighthound, the vertragus, and explicitly locates it among the Celts/Gauls; (2) Arrian, entirely separately, very probably did govern Roman Baetica for a few years in the 120s CE. Nothing in his own surviving text connects these two facts — he does not say he encountered, imported, or hunted with a vertragus while in Spain. The popular "Arrian met the Galgo's ancestor in Baetica" story is a plausible-sounding but textually unsupported bridge built between two true facts by later writers.

## Role of dogs in society

Coursing as Arrian describes it is explicitly a **sport of the wealthy and the enthusiast**, valued for the contest itself rather than economic yield (meat) or even the kill — a genuinely distinct social register from farm/guard dogs (Varro, Columella) and closer to Martial's luxury-gift framing of the same animal.

## Connection to the Galgo Español

**Not established by Arrian's text itself.** The vertragus is Celtic/Gaulish in Arrian's own account. Any connection to Iberia specifically, and ultimately to the Galgo Español, depends on: (a) the *canis gallicus* → *galgo* etymology (name continuity only, per `GE-02-04`), and (b) the general presence of similar coursing dogs in Roman Hispania (see `GE-03-10`), not on anything Arrian says about Spain directly. The Baetica governorship, while real, does not itself supply that missing textual link.

## Competing interpretations

| Question | Position A | Position B |
|---|---|---|
| Did Arrian govern Baetica? | Yes — accepted by Syme, Bosworth, Stadter, and standard prosopography, based on the Córdoba inscription | Minority doubt (Marcovich 1973); a Spanish stylistic study suggests the surviving inscription may be an early-3rd-century copy or a different dedicant |
| Did Arrian encounter/hunt with a vertragus in Spain? | No support in Arrian's own text; the vertragus is consistently Celtic/Gaulish in his account | Popular claim (traceable to a 2011 blog citing breed writer Richard Hawkins) — explicitly labeled speculation even by its originator |

## Evidential limitations

- The Córdoba inscription's precise date and certainty of attribution to Arrian carry a genuine scholarly caveat (possible early-3rd-century copy), even though the mainstream view accepts it.
- This file relies on secondary reporting of the Greek epigraphic text (via Syme, Bosworth, Stadter, and Tovar's original publication) rather than a fresh epigraphic reading of the stone itself.
- Translations of Arrian's Greek (Dansey 1831; Phillips & Willcock 1999) vary in register; readers requiring precise wording for any specific claim should consult the Roos critical Greek text directly.

## Claims table

| Claim ID | Claim | Status | Evidence | Source |
|---|---|---|---|---|
| GE03-04-C1 | Arrian's *Cynegeticus* is the fullest classical source on the vertragus | Confirmed | Extent and detail of the surviving text relative to other classical sources | Arrian, *Cynegeticus* |
| GE03-04-C2 | Arrian locates the vertragus and coursing among the Celts/Gauls, not in Hispania | Confirmed | Direct textual content throughout | Arrian, *Cynegeticus* |
| GE03-04-C3 | Arrian served as Roman proconsul of Baetica, c. 123–126 CE | Probable | Córdoba Artemis inscription; accepted by Syme, Bosworth, Stadter; minority doubt exists | Tovar 1971/1975; Syme 1982; Bosworth 1976; Stadter 1980 |
| GE03-04-C4 | Arrian personally encountered or hunted with a vertragus while in Spain | Traditional claim | No support in Arrian's own text; traced to a 2011 blog's speculative attribution | Dog Law Reporter blog, 2011 (citing Richard Hawkins) |

## Timeline events

- **c. 86 CE:** Approximate birth of Arrian, Nicomedia.
- **c. 123–126 CE:** Probable proconsulship of Baetica.
- **129/130 CE:** Suffect consul.
- **131–137 CE:** Legate of Cappadocia; repels the Alani invasion.
- **136–146 CE (approximate range for composition):** *Cynegeticus* written.
- **145/6 CE:** Archon of Athens.
- **1968:** Discovery of the Córdoba Artemis inscription.
- **1971/1975:** Tovar's publication and republication of the inscription.

## Related entities

- `GE-03-01_xenophon-cynegeticus.md` — the text Arrian responds to.
- `GE-02-02_vertragus-etymology-pre-roman-context.md` — linguistic background to the term Arrian explains.
- `GE-03-10_roman-iberian-archaeology-mosaics.md` — the separate archaeological record of coursing dogs actually found in Roman Spain.
- `00_research_ledger.md` — this file resolves the "Was Arrian's Baetica governorship false?" question flagged there: it is not false, but the associated "met the vertragus in Spain" story is unverified.

## Sources

1. Arrian, *Cynegeticus*. Greek critical text: Roos, A. G. (ed.), *Flavii Arriani quae exstant omnia* II (Teubner, 1928/1968).
2. Dansey, W. (trans.) (1831). *Arrian on Coursing*.
3. Phillips, A. A. & Willcock, M. M. (trans.) (1999). *Xenophon & Arrian: On Hunting*.
4. Tovar, A. (1971). "Un nuevo epigrama griego de Córdoba," in *Estudios sobre la obra de Américo Castro*, Madrid: 401–412.
5. Tovar, A. (1975). "Un nuevo epigrama griego: ¿Arriano de Nicomedia, procónsul de Bética?" *Archivo Español de Arqueología* 48:167–173.
6. Syme, R. (1982). "The Career of Arrian," *Harvard Studies in Classical Philology* 86.
7. Bosworth, A. B. (1976). "Arrian in Baetica," *Greek, Roman, and Byzantine Studies* 17.
8. Stadter, P. A. (1980). *Arrian of Nicomedia*.
9. "Anthropomorphism in Antiquity," Dog Law Reporter (blog), May 2011 — Tier 4, cited only to trace the origin of an unverified popular claim.

## Suggested RAG questions

- Did Arrian govern Baetica, and what is the evidence?
- Does Arrian's Cynegeticus say he encountered the vertragus in Spain?
- What does Arrian say about the purpose of coursing, as distinct from hunting to kill?
