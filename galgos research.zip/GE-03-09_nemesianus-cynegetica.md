---
document_id: "GE-03-09"
title: "Nemesianus's Cynegetica: The Clearest Classical Mention of Spanish-Blooded Hounds"
slug: "nemesianus-cynegetica"
batch: "03"
document_type: "primary_source_analysis"
language: "en"
source_languages: ["la", "en"]
period_start: "283 CE"
period_end: "284 CE"
geographies: ["Carthage", "Hispania", "Britain", "Pannonia", "Libya", "Tuscany"]
entities: []
people: ["Nemesianus"]
dog_types: ["Spartan", "Molossian", "Pannonian"]
topics: ["breed catalogue", "Spanish-blooded hounds", "whelp selection"]
evidence_level: "confirmed"
source_quality: "tier_1"
created_at: "2026-08-30"
updated_at: "2026-08-30"
version: "1.0"
citation_count: 1
review_status: "draft"
---

# Nemesianus's Cynegetica: The Clearest Classical Mention of Spanish-Blooded Hounds

## Executive summary

Marcus Aurelius Olympius Nemesianus of Carthage, writing under the emperors Carinus and Numerian (283/284 CE), gives what this batch identifies as the **most explicit classical mention of dogs "of Spanish blood"** in a hunting-breed context — though he lists Spain alongside Britain, Pannonia, Libya, and Tuscany without singling it out for special praise or detailed description.

## Historical context

Nemesianus's *Cynegetica* survives incomplete, with roughly 325 hexameters extant. Standard citation is by line; the Loeb edition (Duff & Duff, *Minor Latin Poets*, 1934) and LacusCurtius (penelope.uchicago.edu/Thayer/E/Roman/Texts/Nemesianus) carry the text.

## Evidence

- **Breed origins (lines 224ff):** "But it is not only Spartan whelps or only Molossian which you must rear: sundered Britain sends us a swift sort, adapted to hunting-tasks in our world. You should not disdain the pedigree of the **Pannonian** breed, **nor those whose progeny springs from Spanish blood**. Moreover, keen whelps are produced within the confines of dry Libya... Besides, Tuscan dogs often give a satisfaction not foreign to us."
- **Breeding and whelp selection (lines 103ff, and again near line 497):** detailed advice on mating dogs, and the well-known "ring of fire" test, in which a mother dog is set to rescue her best puppies first from a ring of flame — used as a method of identifying the most valuable offspring.

## Primary-source passages

Nemesianus, *Cynegetica* lines 224ff, paraphrased: good hunting dogs need not come only from Sparta or from the Molossian stock — distant Britain sends a fast breed suited to hunting; the Pannonian bloodline deserves respect too, as do dogs descended from Spanish stock; even the dry lands of Libya produce spirited whelps, and Tuscan dogs, too, are not unwelcome.

## Interpretation

This is the clearest and most explicit classical reference to "Spanish blood" hunting dogs located across this entire batch — clearer than Oppian's unadorned "Iberian dam" (a breeding-scheme mention with no praise attached) and far more explicit than Pliny's total silence on the topic over two centuries earlier. However, three important qualifications apply: (1) Nemesianus lists Spain as one among five regions (Britain, Pannonia, Spain, Libya, Tuscany) without singling it out as superior or distinctive — it receives no more emphasis than any other named source; (2) he gives no description of the Spanish dog's appearance, size, or coursing style, unlike his relatively detailed treatment of British and other stocks elsewhere in the poem; and (3) writing in 283/284 CE, Nemesianus post-dates by roughly a century and a half the height of Roman Hispania's coursing-mosaic art (which peaks in the 3rd–4th centuries, per `GE-03-10`), so his mention is roughly contemporary with, not prior to, the archaeological evidence.

## Role of dogs in society

Nemesianus's poem continues the connoisseurial, geography-by-breed literary tradition already seen in Grattius and Pseudo-Oppian, confirming that by the late 3rd century CE, "dogs of Spanish blood" were a recognized-enough category to warrant a passing mention in a genre self-consciously cataloguing prestigious regional hunting-dog stocks.

## Connection to the Galgo Español

**This is the single strongest textual anchor point in the classical corpus for later claims connecting Roman-era dogs to a Spanish coursing tradition** — but it should still be treated cautiously: Nemesianus names a regional bloodline without describing it, offers no functional or morphological detail, and does not use any term equivalent to "vertragus" or "galgo" in connection with it. This passage supports, at most, a **plausible** claim of continuity of *function* (Spain was recognized as a source of hunting dogs by the late 3rd century CE) — it does not support claims of morphological, population, or name continuity to the modern Galgo Español specifically.

## Competing interpretations

Not significantly contested at the textual level; the main interpretive question is simply how much weight a brief, undescribed mention among five regions can bear, which this file treats conservatively (see Interpretation above).

## Evidential limitations

- The poem's incomplete survival (~325 of an originally longer work) means context around this passage that might have offered more description is lost.
- No accompanying morphological or functional description of the "Spanish blood" dogs survives, sharply limiting what can be inferred beyond the bare fact of the mention.

## Claims table

| Claim ID | Claim | Status | Evidence | Source |
|---|---|---|---|---|
| GE03-09-C1 | Nemesianus names dogs "of Spanish blood" as a recognized hunting-dog stock | Confirmed | Direct textual content, lines 224ff | Nemesianus, *Cynegetica* |
| GE03-09-C2 | Nemesianus singles out the Spanish stock as superior to the other four regions named | Disproven or materially misleading | All five regions (Britain, Pannonia, Spain, Libya, Tuscany) are listed with roughly equal, brief treatment | Nemesianus, *Cynegetica*, lines 224ff |
| GE03-09-C3 | This passage establishes morphological or functional continuity with the modern Galgo Español | Traditional claim | No descriptive detail given; connection requires additional unproven links | Nemesianus, *Cynegetica* (absence of detail) |

## Timeline events

- **283/284 CE:** Composition of Nemesianus's *Cynegetica* under Carinus and Numerian.

## Related entities

- `GE-03-08_oppian-cynegetica.md` — the other, slightly earlier Iberian-dog mention.
- `GE-03-10_roman-iberian-archaeology-mosaics.md` — the roughly contemporary archaeological record of Hispano-Roman coursing scenes.
- `GE-03-05_pliny-naturalis-historia.md` — the earlier silence this passage contrasts with.

## Sources

1. Nemesianus, *Cynegetica*. Duff, J. W. & Duff, A. M. (trans.) (1934), *Minor Latin Poets*, Loeb Classical Library; LacusCurtius.

## Suggested RAG questions

- What does Nemesianus say about dogs of Spanish blood, and how does it compare to other regional breeds he names?
- Why should Nemesianus's mention of Spanish-blooded hounds be treated cautiously rather than as strong evidence for the Galgo's ancestry?
