---
document_id: "GE-00-06"
title: "Research Ledger"
slug: "research-ledger"
batch: "00"
document_type: "timeline"
language: "en"
source_languages: []
period_start: ""
period_end: ""
geographies: []
entities: []
people: []
dog_types: []
topics: ["project tracking"]
evidence_level: "unsupported"
source_quality: "tier_1"
created_at: "2026-08-30"
updated_at: "2026-08-30"
version: "1.0"
citation_count: 0
review_status: "draft"
---

# Research Ledger

Live tracking of batch status. Updated after every batch is delivered.

| Batch | Scope | Status | Files delivered | Open questions / follow-ups |
|---|---|---|---|---|
| 00 | Research architecture | **Complete** | 6 | — |
| 01 | Deep prehistory & ancient sighthound context | **Complete** | 5 | Re-check Pires et al. (2019) vs. Marsh et al. (2026) tension when new aDNA data appears |
| 02 | Celts, Iberians, pre-Roman Europe | **Complete** | 4 | No Celtiberian gracile-dog archaeology located — recheck against specialist excavation reports; no Galgo-specific ancient-DNA study located — recheck in Batch 12; presence/absence of dog ex-votos at Iberian sanctuaries unresolved; "6th century BCE Celtic introduction" date has no located primary source |
| 03 | Greece and Rome | **Complete** | 11 | Arrian's Baetica governorship confirmed (not debunked) via Córdoba inscription; "he met the vertragus in Spain" = unverified embellishment; "Codex Romanicus" = disproven, does not exist; "leaping galgo at La Olmeda" = unverified, not in scholarly descriptions; strongest textual/archaeological anchor so far is Nemesianus's "Spanish blood" hounds + Mérida/Córdoba coursing mosaics, but only supports function/morphology continuity, not population/breed |
| 04 | Late Antiquity / Visigothic | Pending | 0 | — |
| 05 | Al-Andalus / North Africa | Pending | 0 | — |
| 06 | Medieval fueros and law | Pending | 0 | — |
| 07 | Medieval literature and hunting manuals | Pending | 0 | — |
| 08 | 1450–1700 | Pending | 0 | — |
| 09 | 1700–1900 | Pending | 0 | — |
| 10 | 1900–2000 | Pending | 0 | — |
| 11 | 2000–present | Pending | 0 | — |
| 12 | Science of origin and continuity | Pending | 0 | — |
| 13 | Synthesis | Pending | 0 | — |

## Known high-risk claims to verify carefully (flagged in advance from the brief)

- The popular "Fuero de Salamanca" galgo story — do not repeat unless the exact provision is located and verified (Batch 06).
- ~~Whether Arrian governed Baetica~~ — **Resolved in Batch 03: confirmed by modern prosopography (Syme, Bosworth, Stadter) via the Córdoba Artemis inscription, c. 123–126 CE.** The separate claim that he "met the vertragus in Spain" remains unverified.
- ~~The supposed "Codex Romanicus"~~ — **Resolved in Batch 03: no such text exists; most likely a conflation of the Cynegetica tradition and the late Roman legal codices.**
- "Galgo descends from the vertragus" and "galgo descends from the Moorish sloughi" — both to be evaluated per the five-continuity framework, not accepted whole.
- Any claim of unbroken genetic/population continuity from antiquity to the present-day closed studbook.

## Suggested RAG questions

- What is the current status of the Galgo Español research project?
- Which claims were flagged in advance as needing extra scrutiny?
