---
document_id: "GE-03-07"
title: "Columella's De Re Rustica Book VII: Excluding the Hunting Dog"
slug: "columella-de-re-rustica"
batch: "03"
document_type: "primary_source_analysis"
language: "en"
source_languages: ["la", "en"]
period_start: "60 CE"
period_end: "65 CE"
geographies: ["Gades (Baetica)", "Rome"]
entities: []
people: ["Columella"]
dog_types: ["villaticus", "pastoralis"]
topics: ["farm dogs", "guard dogs", "agricultural treatise"]
evidence_level: "confirmed"
source_quality: "tier_1"
created_at: "2026-08-30"
updated_at: "2026-08-30"
version: "1.0"
citation_count: 1
review_status: "draft"
---

# Columella's De Re Rustica Book VII: Excluding the Hunting Dog

## Executive summary

Lucius Iunius Moderatus Columella — notably, himself from Gades (modern Cádiz) in Roman Baetica — treats dogs in Book VII of his *De Re Rustica* (c. 60–65 CE), immediately after sheep, goats, and pigs. He **explicitly and deliberately excludes the hunting dog** as a distraction from farm work, treating only the farm-yard guard dog and the shepherd dog in detail. His Baetican origin makes this exclusion an interesting negative data point for the Iberian question specifically.

## Historical context

Columella's *De Re Rustica* is one of the most comprehensive surviving Roman agricultural manuals. Book VII covers smaller livestock and the farm dog. Text available at LacusCurtius (Forster/Heffner Loeb translation).

## Evidence

- **Explicit exclusion (VII.11.2/VII.12.1):** the hunting dog "not only does not help the farmer but actually lures him away from his work, and makes him lazy about it" — a value judgment, not an assertion that hunting dogs didn't exist.
- **The farm-yard guard dog (*villaticus*):** heavily built, large head, drooping ears, black coat (to frighten thieves by day, be invisible by night).
- **The shepherd dog (*pastoralis*):** white (to distinguish it from a wolf at dawn/dusk), long and slim, strong and fast enough to repel or pursue a wolf.
- **On canine loyalty (VII.12.1):** "*Quis famulus amantior domini? Quis fidelior comes? Quis custos incorruptior? Quis excubitor inveniri potest vigilantior?*" ("What servant is fonder of his master? What companion more faithful? What guardian more incorruptible? What watchman can be found more vigilant?")
- **Naming conventions (VII.12.13):** recommends two-syllable names, giving Greek and Latin examples — *Scylax/Ferox, Lacon/Celer* (male); *Spudé, Alké, Rhomé / Lupa, Cerva, Tigris* (female) — a naming convention closely paralleling Xenophon's much earlier list (see `GE-03-01`).

## Primary-source passages

Columella, *De Re Rustica* VII.12.1, quoted (Latin, per LacusCurtius/Forster-Heffner Loeb): "*Quis famulus amantior domini? Quis fidelior comes? Quis custos incorruptior? Quis excubitor inveniri potest vigilantior?*" — "What servant is fonder of his master? What companion more faithful? What guardian more incorruptible? What watchman can be found more vigilant?"

## Interpretation

Columella's exclusion of the hunting dog is a *deliberate authorial choice* clearly stated in his own text (hunting distracts farmers from their work), not evidence that hunting/coursing dogs were absent from his native Baetica or from Roman agricultural society generally. Given that Columella wrote from direct personal knowledge of Baetica (he was born in Gades), his silence on any distinctively Baetican hunting-dog type is a modest negative data point — consistent with, though far from proof of, the broader pattern in this batch that no classical author before Nemesianus (writing over two centuries later) explicitly credits Spain with a notable dog stock (see `GE-03-09`).

## Role of dogs in society

Columella's material reinforces the same guard/shepherd-dog social role already documented in Varro, with the added, quotable emphasis on canine fidelity as an admired trait — a sentiment echoed across nearly every classical author surveyed in this batch (Pliny, Arrian, Martial), suggesting genuine cross-genre Roman cultural consensus on the dog's loyalty regardless of functional type.

## Connection to the Galgo Español

None established. Columella's Baetican origin makes his silence on hunting dogs worth flagging as a data point, but it cannot be read as either confirming or denying the presence of coursing dogs in 1st-century Baetica — he simply does not discuss the topic, by his own explicit choice.

## Competing interpretations

Not contested; Columella's authorial intent is explicitly and unambiguously stated in his own text.

## Evidential limitations

- The absence of hunting-dog material in a Baetica-born author is suggestive but weak negative evidence, given that Columella explicitly states he is choosing not to discuss the topic for reasons unrelated to its prevalence.

## Claims table

| Claim ID | Claim | Status | Evidence | Source |
|---|---|---|---|---|
| GE03-07-C1 | Columella deliberately excludes the hunting dog from his treatise as a distraction from farm work | Confirmed | Direct authorial statement | Columella, *De Re Rustica* VII.11.2/12.1 |
| GE03-07-C2 | Columella's Baetican origin implies knowledge (or lack thereof) of a Baetican coursing-dog type | Unsupported | Text is silent on the matter by explicit choice, not by omission of knowledge | Columella, *De Re Rustica* VII.12 |

## Timeline events

- **c. 60–65 CE:** Composition of Columella's *De Re Rustica*.

## Related entities

- `GE-03-06_varro-de-re-rustica.md` — the earlier agricultural writer with a parallel functional distinction.
- `GE-03-09_nemesianus-cynegetica.md` — the later source that does explicitly mention Spanish-blooded hunting dogs.
- `GE-03-10_roman-iberian-archaeology-mosaics.md` — the archaeological record from Columella's home region, Baetica, which does show coursing scenes by the 4th century.

## Sources

1. Columella, *De Re Rustica* VII.11–12. Forster/Heffner Loeb translation; LacusCurtius.

## Suggested RAG questions

- Why does Columella exclude the hunting dog from his agricultural treatise?
- What does Columella say about canine loyalty, and how does it compare to other classical authors?
