---
document_id: "GE-03-01"
title: "Xenophon's Cynegeticus: Scent-Hunting Before the Sighthound"
slug: "xenophon-cynegeticus"
batch: "03"
document_type: "primary_source_analysis"
language: "en"
source_languages: ["grc", "en"]
period_start: "~430 BCE"
period_end: "~354 BCE"
geographies: ["Greece", "Laconia"]
entities: []
people: ["Xenophon"]
dog_types: ["Laconian hound", "Castorian", "Vulpine (alopekis)"]
topics: ["scent hunting", "Laconian hounds", "classical hunting treatises"]
evidence_level: "confirmed"
source_quality: "tier_1"
created_at: "2026-08-30"
updated_at: "2026-08-30"
version: "1.0"
citation_count: 3
review_status: "draft"
---

# Xenophon's Cynegeticus: Scent-Hunting Before the Sighthound

## Executive summary

Xenophon of Athens (c. 430–354 BCE) wrote the earliest surviving Greek hunting treatise, the *Cynegeticus* (Κυνηγετικός). It describes Laconian (Spartan) scent hounds working with nets, not sighthound coursing. This file exists primarily to establish the *baseline* against which Arrian later defines the vertragus by explicit contrast — Xenophon is the author Arrian argues against.

## Historical context

Xenophon is better known for the *Anabasis* and *Hellenica*; the *Cynegeticus* is a specialized didactic work on hunting technique, hound-keeping, and (in its final chapters) hunting's moral/educational value. Standard citation is by chapter and section (e.g., *Cyn.* III.1, IV.1). The Greek text and E. C. Marchant's Loeb translation are digitized on Perseus (urn:cts:greekLit:tlg0032.tlg014) and ToposText (topostext.org/work/796).

## Evidence

- **Laconian hound varieties (*Cyn.* III.1):** two types — the **Castorian** (named for Castor) and the **Vulpine** (*alopekis*, thought to be dog–fox crosses).
- **Physical ideal (*Cyn.* IV.1, 7–8):** large, small head, straight nose, upright ears, long supple neck, black sparkling eyes; tan-and-white or black-and-tan coat.
- **Method — scent, not sight (*Cyn.* IV.5):** hounds "give chase vigorously without relaxing, with much clamor and baying... giving tongue properly again and again." Prey is driven into nets strung across its path (*Cyn.* VI, X). For boar he prescribes Indian, Cretan, Locrian, and Laconian hounds plus nets, javelins, and spears (*Cyn.* X.1).
- **Forty-seven recommended dog names (*Cyn.* VII.5):** Xenophon recommends short (two-syllable) names, listing exactly forty-seven, including *Hormé* ("Impulse/Rush") — the very name Arrian later gave his own vertragus, a detail worth noting as a literary echo across five and a half centuries.

## Primary-source passages

- *Cyn.* IV.5, paraphrased: Laconian hounds pursue prey continuously and noisily, baying repeatedly as they track it by scent.
- Arrian later quotes/criticizes Xenophon's remark that hares are caught "contrary to the nature of the animal, by accident" — Xenophon's own acknowledgment that scent-hunting with nets was an unreliable, indirect method of catching a hare compared to true coursing.

## Interpretation

Xenophon's treatise is valuable to this project precisely because of what it *lacks*: no sighthound, no coursing by sight, no swift Celtic-type dog. This is not an oversight — it reflects the genuine state of Greek hunting technique in the early 4th century BCE, before the "vertragus" tradition (Celtic in origin, per `GE-02-02` and `GE-03-04`) entered the Greco-Roman literary record several centuries later. Arrian's entire *Cynegeticus* is structured as a explicit corrective to and expansion of Xenophon on exactly this point.

## Role of dogs in society

Dogs are working hunting partners integrated into an aristocratic Greek leisure/educational practice; naming conventions (two-syllable, symbolic names like "Impulse" or "Rush") suggest an individualized, affectionate relationship with hounds already in the 4th century BCE.

## Connection to the Galgo Español

None, directly. This file's relevance is entirely as backdrop: it establishes that scent-hunting-with-nets, not sighthound coursing, was the Greek default before Celtic dogs (and eventually the vertragus tradition) entered classical literature. No connection to the Galgo Español is claimed or implied.

## Competing interpretations

Xenophon's *Cynegeticus* has a disputed authenticity question in classical scholarship (the "pseudo-Xenophon" debate over parts of the corpus), though Arrian himself accepted it as a genuine work by the historian Xenophon and engaged with it as such. This project does not attempt to resolve the authenticity debate; it is noted for completeness.

## Evidential limitations

- This file relies on Marchant's Loeb translation and standard chapter/section citation; a specialist in Xenophontic Greek should be consulted for any claim requiring fine textual nuance.
- The authenticity debate over parts of the corpus is noted but not adjudicated here.

## Claims table

| Claim ID | Claim | Status | Evidence | Source |
|---|---|---|---|---|
| GE03-01-C1 | Xenophon's *Cynegeticus* describes only scent-hunting with nets, not sighthound coursing | Confirmed | Direct textual content, chapters III–X | Xenophon, *Cynegeticus* (Marchant/Loeb, Perseus) |
| GE03-01-C2 | Arrian's *Hormé* echoes a name from Xenophon's list of recommended dog names | Confirmed | Direct textual comparison | Xenophon *Cyn.* VII.5; Arrian *Cynegeticus* |

## Timeline events

- **Late 5th/early 4th century BCE:** Composition of Xenophon's *Cynegeticus*.
- **~2nd century CE:** Arrian writes his own *Cynegeticus* explicitly as a supplement/correction to Xenophon's (see `GE-03-04`).

## Related entities

- `GE-03-04_arrian-cynegeticus.md` — the direct textual successor and corrective.

## Sources

1. Xenophon, *Cynegeticus*. Greek text and E. C. Marchant translation, Perseus Digital Library (urn:cts:greekLit:tlg0032.tlg014).
2. ToposText, "Cynegeticus" (topostext.org/work/796).

## Suggested RAG questions

- What hunting method does Xenophon's *Cynegeticus* describe, and how does it differ from sighthound coursing?
- Why does Arrian structure his own *Cynegeticus* as a response to Xenophon?
