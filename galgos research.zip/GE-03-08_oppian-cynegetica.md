---
document_id: "GE-03-08"
title: "Pseudo-Oppian's Cynegetica: An Iberian Dam in a Roman-Era Breeding Catalogue"
slug: "oppian-cynegetica"
batch: "03"
document_type: "primary_source_analysis"
language: "en"
source_languages: ["grc", "en"]
period_start: "212 CE"
period_end: "217 CE"
geographies: ["Apamea", "Iberia (as breeding stock)"]
entities: []
people: ["Pseudo-Oppian"]
dog_types: ["Laconian", "Molossian"]
topics: ["breed catalogue", "cross-breeding", "Iberian dam"]
evidence_level: "confirmed"
source_quality: "tier_1"
created_at: "2026-08-30"
updated_at: "2026-08-30"
version: "1.0"
citation_count: 1
review_status: "draft"
---

# Pseudo-Oppian's Cynegetica: An Iberian Dam in a Roman-Era Breeding Catalogue

## Executive summary

The Greek didactic poem *Cynegetica*, attributed to "Oppian" but now generally assigned to a different author, Pseudo-Oppian (Oppian of Apamea), was dedicated to the emperor Caracalla, placing it after 212 CE. It gives an extensive dog-breed catalogue including cross-breeding recommendations — notably, one pairing an **Iberian dam with a Sarmatian sire** — the most direct classical mention of an Iberian dog located in this batch's research, though as breeding stock rather than as a named coursing type.

## Historical context

The *Cynegetica* under "Oppian's" name is now attributed to Pseudo-Oppian, distinct from the Oppian of Anazarbus who wrote the *Halieutica* (a poem on fishing). Standard citation is by book and line; the Loeb edition (A. W. Mair, 1928) and LacusCurtius/ToposText (topostext.org/work/525) carry the text.

## Evidence

- **Breed catalogue (I.368–538):** "Those breeds are without number" (I.400).
- **Cross-breeding pairs (I.393–400):** "Mate Arcadian with Elean, Cretan with Paeonian, Carian with Thracian, Tuscan breed with Laconian; **put a Sarmatian sire with an Iberian dam**. So shall you mix the breeds aright; but far best of all it is that the breeds should remain pure." This is a direct textual mention of an **Iberian bitch** used in a breeding scheme — the clearest and most specific classical reference to an Iberian dog located anywhere in this batch's sources.
- **Laconian, recommended for coursing (I.412ff):** praised "for the swift chase of gazelle and deer and swift-footed hare" — one of several breeds credited with genuine coursing ability in this text, alongside (implicitly, via the cross-breeding scheme) the Iberian-Sarmatian cross.
- **Molossian (I.414ff):** "Impetuous and of steadfast valour, who attack even bearded bulls... They are not swift, but they have abundant spirit and genuine strength unspeakable and dauntless courage" — offered as a contrast type, valued for combat rather than speed.
- **Colour preferences (I.430ff):** best hunting dogs are coloured like wolves, tigers, foxes, leopards, or "Demeter's yellow corn"; trackers should be silent (I.449ff).

## Primary-source passages

Pseudo-Oppian, *Cynegetica* I.393–400, paraphrased: the poet advises pairing dogs of different regional stocks to strengthen the breed — Arcadian with Elean, Cretan with Paeonian, Carian with Thracian, Tuscan with Laconian, and a Sarmatian male with an Iberian female — while also noting that keeping bloodlines pure is, on balance, the best approach of all.

## Interpretation

This is a genuinely significant find for the corpus: a Greek author writing under a Roman emperor (Caracalla) treats "Iberian" as a recognized enough regional dog-stock category to be worth naming in a breeding scheme, roughly contemporary with or slightly before Nemesianus's similar mention (see `GE-03-09`). However, two cautions apply: (1) the text does not specify what *kind* of dog this Iberian stock was — fast, gracile, or otherwise — only that it was regionally distinct enough to be named; and (2) it appears in a hypothetical breeding recommendation, not as a description of an existing, observed animal, so it may reflect geographic-diversity theorizing as much as concrete zoological knowledge.

## Role of dogs in society

The elaborate cross-breeding scheme presented here reflects a sophisticated, connoisseurial Roman-era interest in dog breeding by geographic stock — consistent with the pattern already seen in Grattius (nearly two centuries earlier) and pointing toward an increasingly systematized (if still pre-modern, per `GE-01-05`) approach to canine "types" by the early 3rd century CE.

## Connection to the Galgo Español

No direct connection established; this file's Iberian dam reference is valuable primarily as evidence that "Iberian dog stock" was a recognized regional category by the early 3rd century CE, which is a modestly useful data point for the batch's overall argument that Iberian-associated dogs begin appearing by name in classical sources from roughly this period onward (cf. Nemesianus, `GE-03-09`) — but it does not describe the animal in enough detail to support any functional or morphological claim connecting it to the modern Galgo Español.

## Competing interpretations

Not significantly contested; the main open question is simply how literally to read a poetic breeding recommendation as opposed to a description of an actually observed practice — this cannot be resolved from the text alone.

## Evidential limitations

- The brief mention of the Iberian dam gives no morphological detail (size, build, coat), limiting how much weight this passage can bear.
- Authorship uncertainty (Pseudo-Oppian vs. the *Halieutica* Oppian) is well-established in scholarship and noted here for completeness but does not affect the content analysis.

## Claims table

| Claim ID | Claim | Status | Evidence | Source |
|---|---|---|---|---|
| GE03-08-C1 | Pseudo-Oppian's *Cynegetica* names an Iberian dog stock in a breeding scheme | Confirmed | Direct textual content | Pseudo-Oppian, *Cynegetica* I.393–400 |
| GE03-08-C2 | This passage describes the Iberian dog's specific morphology or coursing function | Unsupported | Text names the stock but gives no descriptive detail | Pseudo-Oppian, *Cynegetica* I.393–400 |

## Timeline events

- **After 212 CE (dedication to Caracalla):** Composition of Pseudo-Oppian's *Cynegetica*.

## Related entities

- `GE-03-09_nemesianus-cynegetica.md` — the other, slightly later classical source naming Spanish-blooded hunting dogs.
- `GE-03-05_pliny-naturalis-historia.md` — contrast with Pliny's earlier (1st-century) silence on any Iberian dog.

## Sources

1. Pseudo-Oppian, *Cynegetica* I.368–538. Mair, A. W. (trans.) (1928), Loeb Classical Library; LacusCurtius/ToposText.

## Suggested RAG questions

- What does Pseudo-Oppian's Cynegetica say about an Iberian dog?
- How does this Iberian reference compare to Nemesianus's later mention of Spanish-blooded hounds?
