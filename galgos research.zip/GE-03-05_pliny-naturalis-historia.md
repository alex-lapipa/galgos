---
document_id: "GE-03-05"
title: "Pliny the Elder's Naturalis Historia: Dogs, Loyalty, and Iberian Fauna"
slug: "pliny-naturalis-historia"
batch: "03"
document_type: "primary_source_analysis"
language: "en"
source_languages: ["la", "en"]
period_start: "77 CE"
period_end: "77 CE"
geographies: ["Rome", "Gaul", "India", "Hispania"]
entities: []
people: ["Pliny the Elder"]
dog_types: []
topics: ["dog loyalty", "cross-breeding", "war dogs", "Iberian fauna"]
evidence_level: "confirmed"
source_quality: "tier_1"
created_at: "2026-08-30"
updated_at: "2026-08-30"
version: "1.0"
citation_count: 2
review_status: "draft"
---

# Pliny the Elder's Naturalis Historia: Dogs, Loyalty, and Iberian Fauna

## Executive summary

Pliny the Elder's *Naturalis Historia* (77 CE), the great Roman encyclopedic compendium, treats dogs in its zoological Book VIII — their loyalty, use in war, cross-breeding with wild canids, and hunting sagacity. Book VIII also discusses Iberian/Balearic hares and rabbits, but **gives no distinctively Iberian dog breed**, making this an important negative data point for the corpus.

## Historical context

Book VIII of the *Naturalis Historia* is "The Nature of the Terrestrial Animals." Standard citation is by book and paragraph (Loeb: Rackham; also Perseus, Bostock & Riley; attalus.org). Dog material clusters at VIII.61 (40) "The qualities of the dog; examples of its attachment to its master; nations which have kept dogs for war," VIII.62 "The generation of the dog," and VIII.63 "Remedies against canine madness."

## Evidence

- **Hunting sagacity (VIII.147):** "in hunting... their skill and sagacity is most outstanding. A hound traces and follows footprints... how silent and secret but how significant an indication is given first by the tail and then by the muzzle."
- **Cross-breeding (VIII.148):** "The Indians want hounds to be sired by tigers... Similarly the Gauls breed hounds from wolves; each of their packs has one of the dogs as leader and guide; the pack accompanies this leader in the hunt and pays it obedience." This is a notable early (if likely exaggerated/legendary) attestation of Gaulish wolf-dog crossbreeding lore, distinct from the vertragus material in Grattius/Martial/Arrian.
- **Iberian fauna, not Iberian dogs (VIII.81/55):** Pliny discusses the different species of hares and the Spanish/Balearic rabbit plague (noting the word *cuniculus*, "rabbit," is of Iberian origin) — but he supplies **no distinctively Iberian dog breed** anywhere in Book VIII.
- **General dog loyalty:** Pliny famously calls the dog among the most faithful of animals to man, citing anecdotes of dogs dying alongside or avenging their masters (part of the broader VIII.61 material on canine fidelity).

## Primary-source passages

Pliny, *Naturalis Historia* VIII.148, paraphrased: the Gauls were said to breed their hunting dogs from wolves, with one such wolf-sired dog serving as leader of each pack, which the rest of the pack would follow and obey during the hunt.

## Interpretation

Pliny's silence on a specifically Iberian dog breed, despite discussing Iberian fauna (hares, rabbits) at some length in the very same book, is a meaningful negative result: if a distinctive Iberian coursing dog had been prominent enough for Roman encyclopedic notice by 77 CE, Pliny — writing at exactly this period and with clear interest in canine topics — would be a plausible place to expect it. Its absence is not proof of non-existence, but it weighs against any claim that a well-known "Spanish hound" was already a recognized category in the mid-1st century CE, predating Nemesianus's later (3rd-century) mention of dogs "of Spanish blood" (see `GE-03-09`).

## Role of dogs in society

Pliny's material on canine fidelity and war-dogs reflects a broader Roman cultural valuation of the dog as loyal companion and martial asset, complementing the sporting/luxury framing found in Martial and Arrian and the practical farm framing found in Varro and Columella.

## Connection to the Galgo Español

None established; if anything, this file's contribution is a negative one — Pliny's silence on an Iberian dog breed at this date is a data point cautioning against assuming early, well-established recognition of a specifically Spanish coursing dog.

## Competing interpretations

Not significantly contested; the Gaulish wolf-cross claim (VIII.148) is generally treated by modern scholarship as folklore/legend rather than a literal zoological fact, consistent with Pliny's frequent inclusion of marvel-narratives throughout the *Naturalis Historia*.

## Evidential limitations

- Pliny's *Naturalis Historia* mixes careful observation with received folklore and marvel-tales; the wolf-crossbreeding claim in particular should be read as reported belief, not verified zoology.
- This file surveys only the dog-relevant portions of Book VIII; the work's vast scope means further dog-adjacent material (e.g., in later books) was not exhaustively searched for this batch.

## Claims table

| Claim ID | Claim | Status | Evidence | Source |
|---|---|---|---|---|
| GE03-05-C1 | Pliny discusses dog loyalty, war-dogs, and hunting sagacity in Book VIII | Confirmed | Direct textual content | Pliny, *Naturalis Historia* VIII.61, 147–148 |
| GE03-05-C2 | Pliny reports Gaulish wolf-dog crossbreeding | Confirmed (as a reported ancient claim; not verified zoology) | Direct textual content | Pliny, *Naturalis Historia* VIII.148 |
| GE03-05-C3 | Pliny identifies a distinctively Iberian dog breed | Unsupported | No such passage located despite discussion of Iberian fauna elsewhere in the same book | Pliny, *Naturalis Historia* VIII.81 (absence) |

## Timeline events

- **77 CE:** Publication of Pliny the Elder's *Naturalis Historia*.

## Related entities

- `GE-03-09_nemesianus-cynegetica.md` — the later (3rd-century) source that does mention dogs "of Spanish blood," in contrast to Pliny's silence.

## Sources

1. Pliny the Elder, *Naturalis Historia*, Book VIII. Loeb (Rackham); Perseus (Bostock & Riley); attalus.org.

## Suggested RAG questions

- Does Pliny the Elder mention a distinctively Iberian dog breed?
- What does Pliny say about dog loyalty and Gaulish wolf-crossbreeding?
