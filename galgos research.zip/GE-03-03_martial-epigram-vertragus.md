---
document_id: "GE-03-03"
title: "Martial's Vertragus Epigram (Epigrams XIV.200)"
slug: "martial-epigram-vertragus"
batch: "03"
document_type: "primary_source_analysis"
language: "en"
source_languages: ["la", "en"]
period_start: "84 CE"
period_end: "85 CE"
geographies: ["Rome", "Bilbilis (Hispania)"]
entities: []
people: ["Martial"]
dog_types: ["vertragus"]
topics: ["first explicit naming", "Apophoreta", "luxury animals"]
evidence_level: "confirmed"
source_quality: "tier_1"
created_at: "2026-08-30"
updated_at: "2026-08-30"
version: "1.0"
citation_count: 2
review_status: "draft"
---

# Martial's Vertragus Epigram (Epigrams XIV.200)

## Executive summary

Marcus Valerius Martialis (c. 38/41–104 CE), himself a Spaniard from Bilbilis in Hispania Tarraconensis, gives the **first explicit naming of the vertragus in Latin literature** in Book XIV of his *Epigrams* (the *Apophoreta*, gift-tag couplets for Saturnalia presents), published c. 84–85 CE.

## Historical context

The *Apophoreta* pairs short couplets with the specific gift-objects (and, in some cases, animals) they were meant to accompany at Saturnalia. Epigram XIV.200, titled *Canis vertragus*, is a two-line description meant to accompany the gift of a vertragus dog itself.

## Evidence

> **Latin (Heraeus/Loeb text):** *Non sibi sed domino venatur vertragus acer, / inlaesum leporem qui tibi dente feret.*
> **English (Ker, Loeb):** "The keen vertragus hunts not for himself but for his master, and will bring you the hare unhurt in his teeth."

This couplet is the source of the now-famous "hunts not for himself but for his master" characterization of the breed/type. Neighboring epigrams in the same sequence describe an Asturian horse (XIV.199, *Asturco* — itself an Iberian breed name) and a *catella Gallicana* ("little Gaulish bitch," XIV.198), placing the vertragus in a run of prestige, luxury-import animals given as gifts among the Roman elite. The Latin text is available at Perseus (Heraeus/Borovskij edition) and poesialatina.it; the standard modern philological commentary is T. J. Leary, *Martial Book XIV: The Apophoreta* (1996).

## Primary-source passages

See above — the full two-line epigram is quoted verbatim, as it is short enough to reproduce completely without exceeding this corpus's copyright/citation limits.

## Interpretation

Martial's epigram tells us three things of note: (1) by 84–85 CE the vertragus was familiar enough in Rome to require no explanation, only a punchy two-line characterization; (2) it was regarded as a luxury or prestige animal, grouped with fine imported horses and dogs as Saturnalia gifts; and (3) its most celebrated trait — retrieving the hare unharmed rather than killing it — anticipates and matches Arrian's much fuller description, decades later, of coursing as a sport valuing the chase over the kill (see `GE-03-04`). It is worth noting, without over-reading it, that Martial himself was from Hispania — but the epigram itself makes no claim that the dog is Spanish; it is presented simply as a fashionable Roman luxury item, consistent with the vertragus's established Celtic/Gaulish identity in this literature.

## Role of dogs in society

The vertragus here functions explicitly as a **prestige gift object** among the Roman elite, alongside luxury horses and imported lapdogs — a distinct social role from the working farm/guard dogs of Varro and Columella (see `GE-03-06`, `GE-03-07`) and from the sporting-companion role Arrian later emphasizes.

## Connection to the Galgo Español

None directly established. Martial's Spanish origin is sometimes cited in popular sources as suggestive of an early Iberian connection, but the epigram itself contains no textual basis for that inference — the dog is presented as a Roman luxury import, not as a specifically Spanish animal.

## Competing interpretations

Not substantially contested; this is a short, well-preserved, uncontroversial text at the philological level.

## Evidential limitations

- This is necessarily a very short entry given the brevity of the source text itself; there is little more primary material to add beyond the couplet and its immediate context.

## Claims table

| Claim ID | Claim | Status | Evidence | Source |
|---|---|---|---|---|
| GE03-03-C1 | Martial's *Epigrams* XIV.200 is the first explicit Latin naming of the vertragus | Confirmed | Direct textual/philological consensus | Martial, *Epigrams* XIV.200; Leary 1996 |
| GE03-03-C2 | The epigram identifies the vertragus as specifically Spanish | Disproven or materially misleading | The dog is presented as a Roman luxury import alongside a Gaulish lapdog and an Asturian horse; text does not claim Spanish origin for the dog | Martial, *Epigrams* XIV.198–200 |

## Timeline events

- **c. 84–85 CE:** Publication of Martial's *Epigrams* Book XIV (the *Apophoreta*), including XIV.200.

## Related entities

- `GE-03-02_grattius-cynegeticon.md` — the earlier, less explicit reference.
- `GE-03-04_arrian-cynegeticus.md` — the fuller later treatment of the same "not for himself but for his master" sporting ethic.

## Sources

1. Martial, *Epigrams* XIV.200. Latin text: Heraeus/Borovskij edition (Perseus, poesialatina.it).
2. Leary, T. J. (1996). *Martial Book XIV: The Apophoreta*. Standard modern commentary.

## Suggested RAG questions

- What is the earliest explicit Latin naming of the vertragus, and what does it say?
- Does Martial's epigram establish any connection between the vertragus and Spain?
