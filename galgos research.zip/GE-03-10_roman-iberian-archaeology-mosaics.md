---
document_id: "GE-03-10"
title: "Roman Iberian Archaeology: Coursing Dogs in Hispano-Roman Mosaics and Frescoes"
slug: "roman-iberian-archaeology-mosaics"
batch: "03"
document_type: "archaeology"
language: "en"
source_languages: ["en", "es", "pt"]
period_start: "3rd century CE"
period_end: "5th century CE"
geographies: ["Baetica", "Lusitania", "Tarraconensis", "Mérida", "Córdoba", "Conímbriga", "Itálica"]
entities: ["La Olmeda", "Mérida (Emerita Augusta)", "Córdoba (Corduba)", "Conímbriga", "Itálica", "Centcelles"]
people: ["Guadalupe López Monteagudo", "Milagros Guardia Pons"]
dog_types: ["galgo (descriptive term used by modern scholars)", "lebrel"]
topics: ["Roman mosaics", "venatio", "hare coursing", "named dogs"]
evidence_level: "confirmed"
source_quality: "tier_1"
created_at: "2026-08-30"
updated_at: "2026-08-30"
version: "1.0"
citation_count: 8
review_status: "draft"
---

# Roman Iberian Archaeology: Coursing Dogs in Hispano-Roman Mosaics and Frescoes

## Executive summary

Roman Hispania (3rd–4th centuries CE) has a genuine and well-documented archaeological record of hunting mosaics and frescoes, including several clear coursing/hare-hunting scenes with gracile dogs — some individually named ("AVRA," "NIMBUS," "LATERAS"). Modern Spanish and Portuguese scholarship uses the descriptive terms "galgo" and "lebrel" for these dogs. **However, the dominant subject across the corpus is the big-game hunt (venatio: boar, felines, deer) with generic pack hounds, and no peer-reviewed archaeologist identifies any depicted dog with the modern breed "Galgo Español."**

## Historical context

The comprehensive scholarly syntheses for this material are Guadalupe López Monteagudo, "La caza en el mosaico romano. Iconografía y simbolismo," *Antigüedad y Cristianismo* 8 (1991): 497–512 (open access, digital.csic.es, handle 10261/16509); Milagros Guardia Pons, *Los mosaicos de la Antigüedad tardía en Hispania* (PPU, Barcelona, 1992), esp. pp. 327–335; P. Argüelles Álvarez & D. Piay Augusto, "Escenas cinegéticas en los mosaicos de las villae hispanas y el tratamiento de la caza en las fuentes literarias" (Gredos-USAL, handle 10366/149594); and M. T. Caetano, *Animalia quae lacte aluntur: Mamíferos nos Mosaicos Romanos da Península Ibérica* (Lisbon, 2017).

## Evidence

- **Interpretive frame (López Monteagudo 1991):** hunt mosaics belong to the aristocratic "cycles of the latifundia," exalting the *virtus* and social standing of the *dominus* (estate owner); the iconographic tradition derives from North African mosaics and Hellenistic painting, not a Roman invention. The dominant subject is the big-game hunt (*venatio*) — boar, felines, deer — not hare-coursing.
- **La Olmeda (Pedrosa de la Vega, Palencia; Tarraconensis), 4th c.:** The great *oecus* hunt mosaic is a big-game/venatio composition — lions, leopards, panther, bear, tigress, deer, and a wild boar cornered by a **pack of dogs** ("diversos perros acorralando a un jabalí"). The dogs here are a generic hunting pack (*jauría*), not gracile coursing sighthounds. **A popularly repeated claim of "a leaping galgo pursuing a hare at La Olmeda" is not found in the scholarly descriptions consulted (Palol 1982; Abásolo & Martínez 2012; Abásolo 2013) and should be treated as unverified.**
- **Mérida (Emerita Augusta; Lusitania):**
  - *Casa de la calle Suárez Somonte* fresco (4th c., Museo Nacional de Arte Romano): shows "la caza de la liebre, que es apresada por un lebrel ante la atenta mirada del cazador a caballo" — a hare caught by a coursing hound (*lebrel*), watched by a mounted hunter (Guardia Pons 1992: 327–335). **This is the clearest Hispano-Roman coursing/sighthound image located in this research.**
  - "Avra" mosaic (Asamblea de Extremadura): a **named galgo, "AVRA,"** shown having already caught a hare (F. Palma García, *Mérida, excavaciones arqueológicas* 8, 2002: 159–208).
  - *Villa de las Tiendas/El Hinojal*: mid-4th c. boar-hunt and feline-hunt mosaics with mounted hunters in Constantinian dress.
- **Córdoba (Corduba; Baetica):** the *Mosaico de Thalassius* (4th c.), inscribed *THALASSIUS QUI VENATOR*, shows a mounted hunter whose **named galgos "NIMBUS" and "LATERAS"** course a fleeing hare (López Monteagudo et al. 1999) — a named-sighthound coursing scene specifically located in Baetica, the same province Arrian is credibly recorded to have governed (see `GE-03-04`), though no source connects these two facts directly.
- **Conímbriga (Lusitania):** the *Mosaico do Auriga* (3rd c.), Casa dos Repuxos/Surtidores: a seasonal panel where "unos galgos persiguen la presa" ("galgos pursue the prey") alongside mounted hunters.
- **Itálica (Baetica):** the now-lost *Mosaico de Galatea* showed deer pursued by dogs in woodland (Blanco Freijeiro 1978); the dogs are described only generically.
- **Centcelles (Tarragona; Tarraconensis):** the cupola mausoleum mosaic (late 4th–early 5th c.) has a stag/antelope venatio with the *dominus*, hunters, and dogs, but the dogs are not the emphasized element of the composition.

## Primary-source passages

Guardia Pons (1992: 327–335), paraphrased, on the Mérida Suárez Somonte fresco: the scene depicts a hare hunt in which the animal is caught by a coursing hound, while a mounted hunter looks on attentively.

## Interpretation

This is the most positive archaeological evidence for gracile coursing dogs in Roman Hispania located anywhere in this project's research to date: named, individually depicted sighthound-type dogs genuinely appear at Mérida, Córdoba, and Conímbriga. This should be weighed against the equally clear fact that (a) big-game venatio scenes with generic pack hounds dominate the overall corpus numerically, and (b) the modern descriptive use of "galgo"/"lebrel" by Spanish and Portuguese art historians is exactly that — a modern descriptive convenience for a visually gracile dog type, not a scholarly claim of breed identity with the closed-studbook modern Galgo Español. The two things (a genuinely attested ancient gracile coursing dog in Roman Iberia, and the modern named breed) should be kept as separate claims connected only by *function and morphological resemblance* — the two continuity types this project can most defensibly support here — not by population or formal-breed continuity.

## Role of dogs in society

These mosaics are luxury domestic art commissioned by wealthy villa owners (*domini*) to display status through hunting prowess — coursing dogs here occupy a genuinely prestigious, almost heraldic role (individually named, like a prized possession), closely paralleling the social role Martial and Arrian describe for the vertragus in the broader Roman world (see `GE-03-03`, `GE-03-04`).

## Connection to the Galgo Español

**The strongest — but still explicitly qualified — connection point in this entire batch.** Per the five-continuity framework: **probable continuity of function** (coursing hares with a fast dog, watched/valued by an elite hunter, is a documented Hispano-Roman practice by the 3rd–4th centuries CE) and **plausible continuity of morphological type** (the depicted dogs are visually gracile, consistent with a coursing build) are reasonably supportable from this evidence. **Continuity of population** (an actual unbroken breeding lineage from these Roman-era dogs to the modern Galgo) and **continuity of formal breed** (a 19th–20th century concept, per `GE-01-05`) are **not** established by this material and should not be inferred from it.

## Competing interpretations

The main tension is between (a) enthusiastic popular readings that treat every gracile mosaic dog as "the Galgo Español already there in Roman times," and (b) the more cautious scholarly framing (López Monteagudo, Guardia Pons) that treats "galgo"/"lebrel" as convenient modern descriptive labels for a visual type, not as breed-identification claims. This file follows the latter, more cautious framing throughout.

## Evidential limitations

- Several of the mosaic descriptions here are drawn from secondary Spanish/Portuguese art-historical syntheses rather than from direct examination of the mosaics or their original excavation reports; a future revision could benefit from direct consultation of López Monteagudo (1991) and Guardia Pons (1992) in full.
- The popularly repeated "leaping galgo at La Olmeda" claim is explicitly flagged here as **not found** in the scholarly descriptions consulted and should not be repeated as fact without a located primary source.
- Precise dating of several mosaics (Conímbriga, Itálica) relies on general period attribution (3rd–4th c.) rather than more granular dating in the sources reviewed.

## Claims table

| Claim ID | Claim | Status | Evidence | Source |
|---|---|---|---|---|
| GE03-10-C1 | Hispano-Roman mosaics/frescoes depict hare-coursing scenes with gracile dogs | Confirmed | Multiple independent sites: Mérida, Córdoba, Conímbriga | Guardia Pons 1992; López Monteagudo 1991, 1999; Palma García 2002 |
| GE03-10-C2 | Named individual coursing dogs appear in this art (e.g., "AVRA," "NIMBUS," "LATERAS") | Confirmed | Inscribed mosaic labels | López Monteagudo et al. 1999; Palma García 2002 |
| GE03-10-C3 | Big-game venatio scenes with generic pack hounds dominate the overall Hispano-Roman hunting-mosaic corpus | Confirmed | Comparative frequency across sites (La Olmeda, Itálica, Centcelles, etc.) | López Monteagudo 1991 |
| GE03-10-C4 | A "leaping galgo pursuing a hare" appears at La Olmeda | Unsupported | Not found in the scholarly descriptions of the La Olmeda mosaic consulted | Palol 1982; Abásolo & Martínez 2012; Abásolo 2013 (absence) |
| GE03-10-C5 | These depicted dogs are identified by peer-reviewed archaeologists as the modern Galgo Español breed | Disproven or materially misleading | "Galgo"/"lebrel" used as modern descriptive terms, not breed-identity claims | López Monteagudo 1991; Guardia Pons 1992 |

## Timeline events

- **3rd century CE:** Conímbriga *Mosaico do Auriga*.
- **4th century CE:** Mérida Suárez Somonte fresco; "Avra" mosaic; Córdoba Thalassius mosaic; La Olmeda *oecus* mosaic; Itálica Galatea mosaic (now lost).
- **Late 4th–early 5th century CE:** Centcelles cupola mausoleum mosaic.

## Related entities

- `GE-03-04_arrian-cynegeticus.md` — Arrian's probable Baetican governorship, geographically coinciding with (but not textually linked to) the Córdoba Thalassius mosaic.
- `GE-02-04_competing-origin-hypotheses-pre-roman-coursing.md` — the etymological and pre-Roman background this archaeological evidence sits downstream of.

## Sources

1. López Monteagudo, G. (1991). "La caza en el mosaico romano. Iconografía y simbolismo," *Antigüedad y Cristianismo* 8:497–512.
2. Guardia Pons, M. (1992). *Los mosaicos de la Antigüedad tardía en Hispania*. PPU, Barcelona.
3. Argüelles Álvarez, P. & Piay Augusto, D. "Escenas cinegéticas en los mosaicos de las villae hispanas y el tratamiento de la caza en las fuentes literarias." Gredos-USAL.
4. Caetano, M. T. (2017). *Animalia quae lacte aluntur: Mamíferos nos Mosaicos Romanos da Península Ibérica*. Lisbon.
5. Palma García, F. (2002). *Mérida, excavaciones arqueológicas* 8:159–208.
6. Palol, P. de (1982). *La villa romana de La Olmeda... Guía de las excavaciones*.
7. Abásolo, J. A. & Martínez, R. (2012). Pp. 33–44.
8. Abásolo, J. A. (2013). *Los mosaicos de La Olmeda*.

## Suggested RAG questions

- What archaeological evidence exists for coursing dogs in Roman Spain?
- Do any Hispano-Roman mosaics show individually named dogs?
- Does any peer-reviewed archaeologist identify a Roman-era mosaic dog as the modern Galgo Español breed?
