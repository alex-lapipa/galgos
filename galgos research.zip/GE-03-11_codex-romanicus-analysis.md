---
document_id: "GE-03-11"
title: "The \"Codex Romanicus\": Analysis of a Non-Existent Text"
slug: "codex-romanicus-analysis"
batch: "03"
document_type: "primary_source_analysis"
language: "en"
source_languages: ["en", "la"]
period_start: ""
period_end: ""
geographies: []
entities: []
people: []
dog_types: []
topics: ["debunking", "source conflation", "popular claims"]
evidence_level: "disproven"
source_quality: "tier_1"
created_at: "2026-08-30"
updated_at: "2026-08-30"
version: "1.0"
citation_count: 4
review_status: "draft"
---

# The "Codex Romanicus": Analysis of a Non-Existent Text

## Executive summary

There is **no Roman legal, encyclopedic, or cynegetic (hunting) text known to classical scholarship as the "Codex Romanicus"** dealing with hunting dogs or territorial administration. This label, which recurs in popular Galgo Español breed histories, appears to be a garbled conflation of several genuine but separate things: the *Cynegetica*/*Cynegeticus* literary tradition surveyed throughout this batch, Pliny's *Naturalis Historia*, and/or the real late-Roman legal codices (which postdate the classical hunting-dog authors and concern law, not dogs).

## Historical context

The "Codex Romanicus" claim was flagged in advance in this project's research ledger (`00_research_ledger.md`) as a high-risk item likely to be a garbled popular reference requiring resolution in this batch.

## Evidence

**What does not exist:** No text titled or reliably known as "Codex Romanicus," addressing hunting dogs or territorial/administrative matters, appears in any classical bibliography, library catalogue, or scholarly reference consulted for this batch.

**Most plausible real referents being misremembered or conflated:**
- **The Cynegetica/Cynegeticus tradition** (Xenophon, Grattius, Arrian, Pseudo-Oppian, Nemesianus) — the actual body of ancient "hunting-dog books" surveyed in this batch (`GE-03-01` through `GE-03-09`). Someone recalling "an old Roman book about hunting dogs" is very plausibly recalling this tradition, especially Arrian's or Grattius's work.
- **Pliny the Elder's *Naturalis Historia*** — the great Roman encyclopedic compendium including the dog material discussed in `GE-03-05`. Its scale and "codex-like" comprehensiveness may contribute to the confusion.
- **The genuine late Roman legal codices**, whose names are superficially similar and may supply the "codex" element specifically: the *Codex Gregorianus* (c. 291–294 CE), *Codex Hermogenianus*, *Codex Theodosianus* (438 CE), and *Codex Justinianus* (529–534 CE). These are real, well-documented legal compilations, but they **postdate** the classical hunting-dog authors covered in this batch and concern Roman law generally, not hunting dogs or territorial administration in the specific sense implied by the popular claim.
- **A separate, unrelated bibliographic term:** "Codex Romanus" is a real term in manuscript studies, but denotes entirely unrelated documents — the *Codex Vaticanus Ottobonianus Latinus 1829* (a Catullus manuscript, siglum "R") and the *Vergilius Romanus* (an illustrated Virgil manuscript, c. 500 CE). Neither concerns dogs or administration in any way; this appears to be a case of superficial name-similarity rather than genuine conflation.

## Primary-source passages

Not applicable — this file documents the absence of a text, not the content of one.

## Interpretation

The "Codex Romanicus" is best understood as a modern popular invention or misremembering, most likely arising from an imprecise, secondhand recollection that blends "there were old Roman books about hunting dogs" (true — the Cynegetica tradition) with "there were also famous Roman legal codices" (true, but a different and later body of texts) into a single imagined authoritative source. This is a useful case study in how plausible-sounding but non-existent "ancient sources" can propagate in breed-history literature, and this project treats it as a clear example of the "traditional claim, unverified" — indeed, in this case, **disproven** — category defined in `00_claim_classification_framework.md`.

## Role of dogs in society

Not applicable to this file.

## Connection to the Galgo Español

None — by definition, since the source does not exist, it cannot supply any actual evidence about the Galgo Español's history. This file's function is purely to close off a specific unproductive research lead so that future batches do not waste effort chasing it.

## Competing interpretations

None meaningfully competing; the absence of the text is a straightforward negative finding rather than a matter of scholarly dispute.

## Evidential limitations

- A negative finding (a text does not exist) can never be proven with absolute certainty from a finite search; it remains formally possible that "Codex Romanicus" refers to an extremely obscure or mistitled manuscript not captured by the bibliographic resources consulted. However, no positive evidence for such a text was found across multiple classical-studies resources, and the most parsimonious explanation (conflation of real, well-documented sources) is offered here as the working conclusion.

## Claims table

| Claim ID | Claim | Status | Evidence | Source |
|---|---|---|---|---|
| GE03-11-C1 | A Roman text called "Codex Romanicus" exists, addressing hunting dogs or territorial administration | Disproven or materially misleading | No such text found in any classical bibliography or reference consulted | Absence across multiple classical-studies resources |
| GE03-11-C2 | The "Codex Romanicus" label is a conflation of the Cynegetica tradition and/or the late Roman legal codices | Plausible | Consistent, parsimonious explanation given the superficial similarity of names and subject matter | Analysis in this file |

## Timeline events

Not applicable.

## Related entities

- `GE-03-01` through `GE-03-09` — the actual Cynegetica tradition most likely being misremembered.
- `GE-03-05_pliny-naturalis-historia.md` — the other plausible source of confusion.
- `00_research_ledger.md` — where this claim was originally flagged for verification.

## Sources

1. General classical bibliography and manuscript-studies reference consultation (no single source "proves" a negative; this entry reports the absence of the term across standard classical reference works).
2. Wikipedia, "Codex Vaticanus Ottobonianus Latinus 1829" — used only to identify the unrelated "Codex Romanus" term as a separate bibliographic item, not as historical authority.

## Suggested RAG questions

- Does the "Codex Romanicus" actually exist as a Roman text?
- What real classical texts are most likely being confused or conflated in the "Codex Romanicus" claim?
