---
document_id: "GE-03-06"
title: "Varro's De Re Rustica: The Guard Dog, Not the Hunting Dog"
slug: "varro-de-re-rustica"
batch: "03"
document_type: "primary_source_analysis"
language: "en"
source_languages: ["la", "en"]
period_start: "37 BCE"
period_end: "37 BCE"
geographies: ["Rome"]
entities: []
people: ["Varro"]
dog_types: ["canis pastoralis"]
topics: ["guard dogs", "shepherd dogs", "agricultural treatise"]
evidence_level: "confirmed"
source_quality: "tier_1"
created_at: "2026-08-30"
updated_at: "2026-08-30"
version: "1.0"
citation_count: 1
review_status: "draft"
---

# Varro's De Re Rustica: The Guard Dog, Not the Hunting Dog

## Executive summary

Marcus Terentius Varro (116–27 BCE) discusses dogs in his agricultural treatise *De Re Rustica* (c. 37 BCE) at II.9, but treats **only the guard/shepherd dog**, explicitly setting the hunting dog aside as a different category he does not cover in detail. This file exists to document a genuine and informative absence: Varro acknowledges hunting dogs exist as a distinct functional class but has nothing to say about coursing or sighthounds specifically.

## Historical context

*De Re Rustica* is a practical farming manual in dialogue form. Book II covers livestock, including a discussion of the working farm dog. Text available at LacusCurtius and Perseus (Hooper/Ash Loeb, 1934).

## Evidence

- **Two functional sorts acknowledged (II.9.2):** Varro recognizes "the hunting-dog suited to chase the beasts of the forest, and the other which is procured as a watch-dog" — but treats only the latter in any detail.
- **Guard-dog specifications (II.9.5, 15):** large head, drooping ears, thick neck, wide paws, deep bark, white coat (to distinguish it from a wolf in the dark), fitted with a nail-studded collar (*melium*).
- **Sourcing advice:** buy a guard dog from a shepherd, not a hunter, so that it follows sheep rather than chasing a hare or stag.
- **General household necessity (I.19.3):** "no farm is safe without them."

## Primary-source passages

Varro, *De Re Rustica* II.9.2, paraphrased: there are two kinds of dog worth keeping on a farm — one suited to chasing wild animals in the forest, the other kept as a watchman — and it is specifically the watch-dog that Varro goes on to describe in detail.

## Interpretation

Varro's text is useful precisely for what it deliberately excludes. He is aware that hunting dogs exist as a distinct category from guard/shepherd dogs, but chooses not to elaborate — plausibly because his treatise's practical, agricultural-economy focus has no use for a sporting/luxury animal like the vertragus. This absence should not be read as evidence against sighthounds' existence in this period (Grattius, writing at almost exactly the same moment, already knows the *Vertraha*), only as evidence that Varro's genre and purpose did not require him to discuss them.

## Role of dogs in society

The guard/shepherd dog Varro describes occupies a distinctly utilitarian, agricultural-economy role — protecting livestock and property — a useful contrast to the sporting/prestige role of the vertragus in Martial and Arrian, and a reminder that "dog" covered several quite separate social/functional categories in Roman society simultaneously.

## Connection to the Galgo Español

None. This file is included for completeness per the batch's required source list, and to document the absence of hunting-dog detail in Varro as a data point about genre rather than about the presence or absence of coursing dogs in his era.

## Competing interpretations

Not contested; this is a straightforward, well-preserved technical text.

## Evidential limitations

- Varro's brevity on hunting dogs means this file is necessarily short; there is little additional primary material to draw on.

## Claims table

| Claim ID | Claim | Status | Evidence | Source |
|---|---|---|---|---|
| GE03-06-C1 | Varro distinguishes hunting dogs from guard/shepherd dogs as separate functional categories | Confirmed | Direct textual content | Varro, *De Re Rustica* II.9.2 |
| GE03-06-C2 | Varro provides detailed description of hunting dogs/coursing types | Disproven or materially misleading | Text explicitly treats only the guard dog in detail | Varro, *De Re Rustica* II.9 |

## Timeline events

- **c. 37 BCE:** Composition of Varro's *De Re Rustica*.

## Related entities

- `GE-03-07_columella-de-re-rustica.md` — a later agricultural writer with a similar functional split, discussed at greater length.

## Sources

1. Varro, *De Re Rustica* II.9. Hooper/Ash Loeb translation (1934); LacusCurtius; Perseus.

## Suggested RAG questions

- Does Varro discuss hunting dogs or coursing dogs in detail?
- What kind of dog does Varro's De Re Rustica actually describe?
